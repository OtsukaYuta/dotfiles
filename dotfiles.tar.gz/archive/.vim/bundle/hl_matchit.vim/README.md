hl_matchit.vim
==============

highlighting match of matchit.vim.

please see [doc/hl_matchit.vim][1]
[1]:https://github.com/vimtaku/hl_matchit.vim/blob/master/doc/hl_matchit.txt
